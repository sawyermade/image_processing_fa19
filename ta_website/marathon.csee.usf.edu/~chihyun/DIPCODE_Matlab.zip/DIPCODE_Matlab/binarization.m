function output=binarization(img,threshold)
[rows,cols]=size(img);
output=img;
for r=1:rows
    for c=1:cols
        if img(r,c)<threshold
            output(r,c)=0;
        else
            output(r,c)=255;
        end
    end
end
end