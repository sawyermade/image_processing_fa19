function output=scale(img,ratio)
[rows,cols]=size(img);
output=zeros(rows*ratio,cols*ratio);
for r=1:rows*ratio
    for c=1:cols*ratio
        r2=floor((r-1)/ratio)+1;
        c2=floor((c-1)/ratio)+1;
        if ratio==2
            output(r,c)=img(r2,c2);
        elseif ratio==0.5
            value=double(img(r2,c2))+double(img(r2,c2+1))+double(img(r2+1,c2))+double(img(r2+1,c2+1));
            output(r,c)=round(value/4);
        end
    end
end
output=uint8(output);
end