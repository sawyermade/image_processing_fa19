% This sample project include three functions:				
%   1. Add intensity for gray-level image.					
%      Input: source image, output image name, value			
%  															
%   2. Image thresholding: pixels will become black if the intensity is below the threshold, and white if above or equal the threhold.								
%      Input: source image, output image name, threshold		
%  															
%   3. Image scaling: reduction/expansion of 2 for the width and length. This project uses averaging technique for reduction and pixel replication technique for expansion.								
%      Input: source image, output image name, scale factor

fid=fopen('parameters.txt');
str=fgets(fid);
while str~=-1
    str=strsplit(str,' ');
    filename=str{1};
    output=str{2};
    operation=str{3};
    
    if strcmp(operation,'add')
        parameter=str2double(str{4});
        img=imread(filename);
        imgout=addInt(img,parameter);
        imwrite(imgout,output);
    elseif strcmp(operation,'binarize')
        parameter=str2double(str{4});
        img=imread(filename);
        imgout=binarization(img,parameter);
        imwrite(imgout,output);
    elseif strcmp(operation,'scale')
        parameter=str2double(str{4});
        img=imread(filename);
        imgout=scale(img,parameter);
        imwrite(imgout,output);
    else
        fprintf('No function: %s\n', operation);
    end
    
    str=fgets(fid);
end