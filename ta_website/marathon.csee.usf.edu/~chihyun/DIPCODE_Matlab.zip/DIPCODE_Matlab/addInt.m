function output=addInt(img,value)
[rows,cols]=size(img);
output=img;
for r=1:rows
    for c=1:cols
        v=img(r,c)+value;
        if v>255
            v=255;
        elseif v<0
            v=0;
        end
        output(r,c)=v;
    end
end
end